#include "provided.h"
#include <iostream>
#include <vector>
using namespace std;

class MatcherImpl
{
public:
    MatcherImpl(istream& ruleStream);
    void process(Document& doc, double minPrice, vector<Match>& matches) const;
};

MatcherImpl::MatcherImpl(istream& ruleStream)
{
}

void MatcherImpl::process(Document& doc, double minPrice, vector<Match>& matches) const
{
}

//******************** Matcher functions *******************************

// These functions simply delegate to MatcherImpl's functions.
// You probably don't want to change any of this code.

Matcher::Matcher(istream& ruleStream)
{
    m_impl = new MatcherImpl(ruleStream);
}

Matcher::~Matcher()
{
    delete m_impl;
}

void Matcher::process(Document& doc, double minPrice, vector<Match>& matches) const
{
    m_impl->process(doc, minPrice, matches);
}
