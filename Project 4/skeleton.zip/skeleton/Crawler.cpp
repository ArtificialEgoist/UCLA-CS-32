#include "provided.h"
#include <string>
using namespace std;

class CrawlerImpl
{
public:
    CrawlerImpl(string seedSite);
    Document* crawl();
};

CrawlerImpl::CrawlerImpl(string seedSite)
{
}

Document* CrawlerImpl::crawl()
{
    return NULL;  // This is not always correct; it's just here to compile.
}

//******************** Crawler functions *******************************

// These functions simply delegate to CrawlerImpl's functions.
// You probably don't want to change any of this code.

Crawler::Crawler(string seedSite)
{
    m_impl = new CrawlerImpl(seedSite);
}

Crawler::~Crawler()
{
    delete m_impl;
}

Document* Crawler::crawl()
{
    return m_impl->crawl();
}
