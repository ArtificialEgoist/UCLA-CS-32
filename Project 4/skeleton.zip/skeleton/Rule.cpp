#include "provided.h"
#include <string>
using namespace std;

class RuleImpl
{
public:
    RuleImpl(string ruleText);
    string getName() const;
    double getDollarValue() const;
    int getNumElements() const;
    string getElement(int elementNum) const;
    string getAd() const;
    bool match(const Document& doc) const;
};

RuleImpl::RuleImpl(string ruleText)
{
}

string RuleImpl::getName() const
{
    return "";  // This is not always correct; it's just here to compile.
}

double RuleImpl::getDollarValue() const
{
    return 0.0;  // This is not always correct; it's just here to compile.
}

int RuleImpl::getNumElements() const
{
    return 0;  // This is not always correct; it's just here to compile.
}

string RuleImpl::getElement(int elementNum) const
{
    return "";  // This is not always correct; it's just here to compile.
}

string RuleImpl::getAd() const
{
    return "";  // This is not always correct; it's just here to compile.
}

bool RuleImpl::match(const Document& doc) const
{
    return false;  // This is not always correct; it's just here to compile.
}

//******************** Rule functions *******************************

// These functions simply delegate to RuleImpl's functions.
// You probably don't want to change any of this code.

Rule::Rule(string ruleText)
{
    m_impl = new RuleImpl(ruleText);
}

Rule::~Rule()
{
    delete m_impl;
}

Rule::Rule(const Rule& other)
 : m_impl(new RuleImpl(*other.m_impl))
{}

Rule& Rule::operator=(const Rule& other)
{
    if (this != &other)
    {
        RuleImpl* copyOfOther = new RuleImpl(*other.m_impl);
        delete m_impl;
        m_impl = copyOfOther;
    }
    return *this;
}

string Rule::getName() const
{
    return m_impl->getName();
}

double Rule::getDollarValue() const
{
    return m_impl->getDollarValue();
}

int Rule::getNumElements() const
{
    return m_impl->getNumElements();
}

string Rule::getElement(int elementNum) const
{
    return m_impl->getElement(elementNum);
}

string Rule::getAd() const
{
    return m_impl->getAd();
}

bool Rule::match(const Document& doc) const
{
    return m_impl->match(doc);
}
