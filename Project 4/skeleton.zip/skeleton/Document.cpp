#include "provided.h"
#include <string>
using namespace std;

class DocumentImpl 
{
public:
    DocumentImpl(string url, const string& text);
    string getURL() const;
    bool contains(string word) const;
    bool getFirstWord(string& word);
    bool getNextWord(string& word);
};

DocumentImpl::DocumentImpl(string url, const string& text)
{
}

string DocumentImpl::getURL() const
{
    return "";  // This is not always correct; it's just here to compile.
}

bool DocumentImpl::contains(string word) const
{
    return false;  // This is not always correct; it's just here to compile.
}

bool DocumentImpl::getFirstWord(string& word)
{
    return false;  // This is not always correct; it's just here to compile.
}

bool DocumentImpl::getNextWord(string& word)
{
    return false;  // This is not always correct; it's just here to compile.
}

//******************** Document functions *******************************

// These functions simply delegate to DocumentImpl's functions.
// You probably don't want to change any of this code.

Document::Document(string url, const string& text)
{
    m_impl = new DocumentImpl(url, text);
}

Document::~Document()
{
    delete m_impl;
}

string Document::getURL() const
{
    return m_impl->getURL();
}

bool Document::contains(string word) const
{
    return m_impl->contains(word);
}

bool Document::getFirstWord(string& word)
{
    return m_impl->getFirstWord(word);
}

bool Document::getNextWord(string& word)
{
    return m_impl->getNextWord(word);
}
