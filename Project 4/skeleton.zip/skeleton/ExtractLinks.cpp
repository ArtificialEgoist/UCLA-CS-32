#include "provided.h"
#include <string>
using namespace std;

class ExtractLinksImpl
{
public:
    ExtractLinksImpl(const string& pageContents);
    bool getNextLink(string& link);
};

ExtractLinksImpl::ExtractLinksImpl(const string& pageContents)
{
}

bool ExtractLinksImpl::getNextLink(string& link)
{
    return false;  // This is not always correct; it's just here to compile.
}

//******************** ExtractLink functions *******************************

// These functions simply delegate to ExtractLinksImpl's functions.
// You probably don't want to change any of this code.

ExtractLinks::ExtractLinks(const string& pageContents)
{
    m_impl = new ExtractLinksImpl(pageContents);
}

ExtractLinks::~ExtractLinks()
{
    delete m_impl;
}

bool ExtractLinks::getNextLink(string& link)
{
    return m_impl->getNextLink(link);
}
