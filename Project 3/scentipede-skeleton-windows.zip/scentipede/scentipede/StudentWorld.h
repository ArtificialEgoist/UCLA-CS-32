#ifndef _StudentWorld_H_
#define _StudentWorld_H_

// students - add your code here!

class StudentWorld: public GameWorld
{
public:
	virtual void init()
	{
	}

	virtual int move()
	{
		return 0;
	}


	virtual void cleanUp() 
	{
	}

private:
};

#endif // #ifndef _StudentWorld_H_
