#include "SoundFX.h"

std::map<std::string, char *>		SoundFX::m_loadedSounds;
