#include "graphobj.h"

std::set<GraphObject *>	GraphObject::m_graphObjects;
