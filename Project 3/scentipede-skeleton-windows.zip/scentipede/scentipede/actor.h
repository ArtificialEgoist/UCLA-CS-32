#ifndef _ACTOR_H_

#define _ACTOR_H_

#include "GraphObj.h"
#include "GameConstants.h"

#include "GameWorld.h"

// students - add your code here!

#endif // #ifndef _ACTOR_H_
